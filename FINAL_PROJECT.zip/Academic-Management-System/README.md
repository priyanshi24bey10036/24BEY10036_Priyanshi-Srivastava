# Academic Management System

## Project Overview

Academic Management System is a backend-based Student Course Registration System developed using Spring Boot and MongoDB. The project manages academic entities such as Students, Courses, Departments, and Staff members through REST APIs.

The system performs CRUD (Create, Read, Update, Delete) operations and demonstrates relationships between collections in MongoDB.

---

## Features

### Student Management

* Add new students
* View all students
* Update student details
* Delete students
* Assign courses and departments to students

### Course Management

* Add courses
* Update course details
* Delete courses
* View available courses

### Department Management

* Add departments
* Assign HOD staff IDs
* Manage department information

### Staff Management

* Add staff members
* Store designation details
* Update and delete staff records

### Authentication & Security

* Spring Security authentication implemented
* Basic Authentication enabled for all APIs
* Username and password configured in `application.properties`
* Unauthorized users cannot access APIs without valid credentials

Example Credentials:

* Username: admin
* Password: admin123

---

## Technologies Used

* Java
* Spring Boot
* MongoDB
* Maven
* Spring Security
* REST API
* Postman
* VS Code

---

## Database Used

MongoDB database:

```text
academicdb
```

---

## Project Structure

```text
src/main/java
│
├── controller
├── model
├── repository
├── service
│
src/main/resources
│
└── application.properties
```

---

## API Testing

All APIs were tested successfully using Postman.

Implemented API operations:

* GET
* POST
* PUT
* DELETE

---

## Sample Collections

* Students
* Courses
* Departments
* Staff

---

## Relationships Implemented

* One-to-One
* One-to-Many
* Many-to-One
* Many-to-Many

---

## Future Enhancements

The project can be further enhanced by adding:

* Frontend UI using React or Angular
* Student login and registration portal
* Role-based authentication (Admin, Student, Faculty)
* Course enrollment validation
* Attendance management system
* Marks and result management
* Email notifications
* JWT authentication
* Dashboard and analytics
* Cloud database deployment
* File upload for student documents

---

## Conclusion

This project demonstrates backend development using Spring Boot and MongoDB with secure REST APIs and CRUD operations. It provides a foundation for building a complete Academic ERP or Student Management System in future.
