package com.project.Academic_Management_System.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "departments")
public class Department {
@Id
    private String departmentId;

    private String departmentName;

    // One-to-One example
    private String hodStaffId;

    public Department() {}

    public Department(String departmentId, String departmentName, String hodStaffId) {
        this.departmentId=departmentId;
        this.departmentName = departmentName;
        this.hodStaffId = hodStaffId;
    }

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }
    public String getDepartmentName() {
        return departmentName;
    }

    public String getHodStaffId() {
        return hodStaffId;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public void setHodStaffId(String hodStaffId) {
        this.hodStaffId = hodStaffId;
    }
}
