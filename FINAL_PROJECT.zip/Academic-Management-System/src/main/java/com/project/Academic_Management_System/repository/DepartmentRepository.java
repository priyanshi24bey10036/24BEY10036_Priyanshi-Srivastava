package com.project.Academic_Management_System.repository;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.project.Academic_Management_System.model.Department;
public interface DepartmentRepository extends MongoRepository<Department, String> {

}
