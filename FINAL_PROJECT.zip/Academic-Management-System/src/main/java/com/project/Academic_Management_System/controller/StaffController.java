package com.project.Academic_Management_System.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.Academic_Management_System.model.Staff;
import com.project.Academic_Management_System.repository.StaffRepository;

@RestController
@RequestMapping("/staff")
public class StaffController {

    @Autowired
    private StaffRepository repository;

    // INSERT
    @PostMapping
    public Staff createStaff(@RequestBody Staff staff) {
        return repository.save(staff);
    }

    // GET ALL
    @GetMapping
    public List<Staff> getAllStaff() {
        return repository.findAll();
    }

    // GET BY ID
    @GetMapping("/{id}")
    public Staff getStaffById(@PathVariable String id) {

    return repository.findById(id).orElse(null);
}

    // UPDATE
    @PutMapping("/{id}")
    public Staff updateStaff(@PathVariable String id,
    @RequestBody Staff staff) {

        staff.setStaffId(id);
        return repository.save(staff);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteStaff(@PathVariable String id) {

        repository.deleteById(id);
        return "Staff deleted successfully";
    }
}