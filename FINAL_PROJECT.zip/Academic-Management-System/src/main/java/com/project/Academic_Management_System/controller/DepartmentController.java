package com.project.Academic_Management_System.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.Academic_Management_System.model.Department;
import com.project.Academic_Management_System.repository.DepartmentRepository;

@RestController
@RequestMapping("/departments")
public class DepartmentController {

    @Autowired
    private DepartmentRepository repository;

    // INSERT
    @PostMapping
    public Department createDepartment(@RequestBody Department department) {
        return repository.save(department);
    }

    // GET ALL
    @GetMapping
    public List<Department> getAllDepartments() {
        return repository.findAll();
    }
    // GET BY ID
    @GetMapping("/{id}")
    public Department getDepartmentById(@PathVariable String id) {

    return repository.findById(id).orElse(null);
}

    // UPDATE
    @PutMapping("/{id}")
    public Department updateDepartment(@PathVariable String id,
@RequestBody Department department) {

        department.setDepartmentId(id);
        return repository.save(department);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteDepartment(@PathVariable String id) {

        repository.deleteById(id);
        return "Department deleted successfully";
    }
}