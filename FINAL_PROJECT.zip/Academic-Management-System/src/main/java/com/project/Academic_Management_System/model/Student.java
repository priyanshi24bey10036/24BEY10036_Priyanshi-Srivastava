package com.project.Academic_Management_System.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "students")
public class Student {
@Id
    private String studentid;

    private String name;
    private int age;
    private String email;

    // Many students belong to one department
    private String departmentId;

    // Many-to-many mapping
    private List<String> courseIds;

    public Student() {}

    public Student(String studentid, String name, int age, String email, String departmentId, List<String> courseIds) {
        this.studentid = studentid;
        this.name = name;
        this.age = age;
        this.email = email;
        this.departmentId = departmentId;
        this.courseIds = courseIds;
    }

    public String getStudentId() {
        return studentid;
    }

    public void setStudentId(String studentid) {
    this.studentid = studentid;
}
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getDepartmentId() {
        return departmentId;
    }

    public List<String> getCourseIds() {
        return courseIds;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    public void setCourseIds(List<String> courseIds) {
        this.courseIds = courseIds;
    }
}
