package com.project.Academic_Management_System.repository;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.project.Academic_Management_System.model.Student;

public interface StudentRepository extends MongoRepository<Student, String> {

}
