package com.project.Academic_Management_System.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.Academic_Management_System.model.Student;
import com.project.Academic_Management_System.repository.StudentRepository;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentRepository repository;

    // INSERT
    @PostMapping
    public Student createStudent(@RequestBody Student student) {
        return repository.save(student);
    }

    // GET ALL
    @GetMapping
    public List<Student> getAllStudents() {
        return repository.findAll();
    }
// GET BY ID
    @GetMapping("/{id}")
    public Student getStudentById(@PathVariable String id) {

    return repository.findById(id).orElse(null);
}

    // UPDATE
    @PutMapping("/{id}")
    public Student updateStudent(@PathVariable String id,
@RequestBody Student student) {

        student.setStudentId(id);
        return repository.save(student);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteStudent(@PathVariable String id) {

        repository.deleteById(id);
        return "Student deleted successfully";
    }
}