package com.project.Academic_Management_System.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.Academic_Management_System.model.Course;
import com.project.Academic_Management_System.repository.CourseRepository;

@RestController
@RequestMapping("/courses")
public class CourseController {

    @Autowired
    private CourseRepository repository;

    // INSERT
    @PostMapping
    public Course createCourse(@RequestBody Course course) {
        return repository.save(course);
    }

    // GET ALL
    @GetMapping
    public List<Course> getAllCourses() {
        return repository.findAll();
    }
     // GET BY ID
    @GetMapping("/{id}")
    public Course getCourseById(@PathVariable String id) {

    return repository.findById(id).orElse(null);
}


    // UPDATE
    @PutMapping("/{id}")
    public Course updateCourse(@PathVariable String id,
    @RequestBody Course course) {

        course.setCourseId(id);
        return repository.save(course);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteCourse(@PathVariable String id) {

        repository.deleteById(id);
        return "Course deleted successfully";
    }
}