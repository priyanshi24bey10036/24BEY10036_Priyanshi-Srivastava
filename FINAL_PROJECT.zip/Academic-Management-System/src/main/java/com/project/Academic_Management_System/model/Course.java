package com.project.Academic_Management_System.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "courses")
public class Course {

@Id
    private String courseid;

    private String courseName;
    private int duration;

    public Course() {}

    public Course(String courseid, String courseName, int duration) {
        this.courseid = courseid;
        this.courseName = courseName;
        this.duration = duration;
    }

    public String getCourseId() {
        return courseid;
    }

    public void setCourseId(String courseid) {
        this.courseid = courseid;
    }
    public String getCourseName() {
        return courseName;
    }

    public int getDuration() {
        return duration;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }
}
