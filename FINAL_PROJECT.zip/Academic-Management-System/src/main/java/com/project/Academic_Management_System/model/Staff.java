package com.project.Academic_Management_System.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "staff")
public class Staff {
@Id
    private String staffid;

    private String name;
    private String designation;

    public Staff() {}

    public Staff(String staffid, String name, String designation) {
        this.staffid = staffid;
        this.name = name;
        this.designation = designation;
    }

    public String getStaffId() {
        return staffid;
    }

    public void setStaffId(String staffid) {
        this.staffid = staffid;
    }

    public String getName() {
        return name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }
}
