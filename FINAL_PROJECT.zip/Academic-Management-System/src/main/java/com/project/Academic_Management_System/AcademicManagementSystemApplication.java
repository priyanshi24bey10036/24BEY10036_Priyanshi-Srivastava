package com.project.Academic_Management_System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademicManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcademicManagementSystemApplication.class, args);
	}

}
